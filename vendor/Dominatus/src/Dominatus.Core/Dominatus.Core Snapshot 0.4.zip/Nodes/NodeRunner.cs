﻿using Dominatus.Core.Blackboard;
using Dominatus.Core.Nodes.Steps;
using Dominatus.Core.Runtime;
using System.Threading.Channels;
using System.Xml.Linq;

namespace Dominatus.Core.Nodes;

public enum NodeStatus
{
    Running,
    Succeeded,
    Failed
}

public readonly record struct NodeTickResult(
    bool HasEmittedStep,
    AiStep? EmittedStep,
    NodeStatus? CompletedStatus)
{
    public static NodeTickResult Running() => new(false, null, NodeStatus.Running);
    public static NodeTickResult Emitted(AiStep step) => new(true, step, null);
    public static NodeTickResult Completed(NodeStatus status) => new(false, null, status);
}

public sealed class NodeRunner(AiNode node)
{
    private IEnumerator<AiStep>? _it;

    private float _waitStartTime;
    private WaitSeconds? _waitSeconds;
    private WaitUntil? _waitUntil;

    private CancellationTokenSource? _cts;
    private IWaitEvent? _waitEvent;
    private EventCursor _waitEventCursor;
    private static AiCtx MakeCtx(AiWorld world, AiAgent agent, CancellationToken cancel)
    => new(world, agent, agent.Events, cancel, world.View, world.Mail, world.Actuator);

    public void Enter(AiWorld world, AiAgent agent)
    {
        Exit();

        _cts = new CancellationTokenSource();
        var ctx = MakeCtx(world, agent, _cts.Token);
        _it = node(ctx);
    }

    public void Exit()
    {
        try
        {
            _cts?.Cancel();
        }
        catch { /* ignore */ }

        try
        {
            _it?.Dispose();
        }
        catch { /* ignore */ }

        _it = null;

        _waitSeconds = null;
        _waitUntil = null;
        _waitEvent = null;
        _waitEventCursor = default;
        _waitStartTime = 0;

        _cts?.Dispose();
        _cts = null;
    }

    public NodeTickResult Tick(AiWorld world, AiAgent agent)
    {
        if (_it is null)
            return NodeTickResult.Completed(NodeStatus.Failed);

        var cts = _cts;
        var cancel = cts?.Token ?? CancellationToken.None;
        var ctx = MakeCtx(world, agent, cancel);

        // If canceled, treat as failed completion so HFSM can pop/unwind.
        if (cancel.IsCancellationRequested)
            return NodeTickResult.Completed(NodeStatus.Failed);

        // Handle waits
        if (_waitSeconds is not null)
        {
            if (world.Clock.Time - _waitStartTime >= _waitSeconds.Seconds)
            {
                _waitSeconds = null;
            }
            else
            {
                return NodeTickResult.Running();
            }
        }

        if (_waitUntil is not null)
        {
            bool done;
            try { done = _waitUntil.Predicate(ctx); }
            catch { done = false; }

            if (done)
                _waitUntil = null;
            else
                return NodeTickResult.Running();
        }

        if (_waitEvent is not null)
        {
            if (ctx.Cancel.IsCancellationRequested)
                return NodeTickResult.Completed(NodeStatus.Failed);

            if (!_waitEvent.TryConsume(ctx, ref _waitEventCursor))
                return NodeTickResult.Running();

            _waitEvent = null;
            _waitEventCursor = default;
        }

        // Advance enumerator
        bool moved;
        try { moved = _it.MoveNext(); }
        catch
        {
            return NodeTickResult.Completed(NodeStatus.Failed);
        }

        if (!moved)
        {
            // Default: natural completion == success
            return NodeTickResult.Completed(NodeStatus.Succeeded);
        }

        var step = _it.Current;

        // Null yields are treated as "just keep running"
        if (step is null)
            return NodeTickResult.Running();

        switch (step)
        {
            case WaitSeconds ws:
                if (ws.Seconds <= 0) return NodeTickResult.Running();
                _waitSeconds = ws;
                _waitStartTime = world.Clock.Time;
                return NodeTickResult.Running();

            case WaitUntil wu:
                _waitUntil = wu;
                return NodeTickResult.Running();

            // Control / completion signals are emitted upward to HFSM
            case Goto or Push or Pop or Succeed or Fail:
                return NodeTickResult.Emitted(step);

            case IWaitEvent we:
                _waitEvent = we;
                _waitEventCursor = default;
                return NodeTickResult.Running();

            case Act act:
                {
                    var res = ctx.Act.Dispatch(ctx, act.Command);

                    // Store id if requested
                    if (act.StoreIdAs is BbKey<ActuationId> key)
                        agent.Bb.Set(key, res.Id);

                    // If it completed immediately, publish completion event so Await works uniformly
                    if (res.Completed)
                        agent.Events.Publish(new ActuationCompleted(res.Id, res.Ok, res.Error, res.Payload));

                    // If not accepted, you can choose to fail immediately or just keep going.
                    // I recommend: if not accepted AND completed, let the node handle it via Await/logic.
                    // So we just keep running.
                    return NodeTickResult.Running();
                }

            case AwaitActuation await:
                {
                    // Implement Await as a wait-for-event with a stable cursor
                    var id = agent.Bb.GetOrDefault(await.IdKey, default);

                    _waitEvent = new WaitEvent<ActuationCompleted>(
                        Filter: e => e.Id.Equals(id),
                        OnConsumed: null
                    );

                    _waitEventCursor = default;
                    return NodeTickResult.Running();
                }

            default:
                // Unknown step: treat as emitted so brain can decide later (future-proof)
                return NodeTickResult.Emitted(step);
        }
    }
}