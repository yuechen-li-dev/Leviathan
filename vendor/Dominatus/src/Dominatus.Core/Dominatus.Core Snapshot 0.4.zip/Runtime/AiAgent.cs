﻿using Dominatus.Core.Blackboard;
using Dominatus.Core.Hfsm;

namespace Dominatus.Core.Runtime;

public sealed class AiAgent
{
    public AgentId Id { get; internal set; } // set by AiWorld.Add
    public Blackboard.Blackboard Bb { get; } = new();
    public AiEventBus Events { get; } = new();

    public HfsmInstance Brain { get; }

    public AiAgent(HfsmInstance brain) => Brain = brain;

    public void Tick(AiWorld world) => Brain.Tick(world, this);
}